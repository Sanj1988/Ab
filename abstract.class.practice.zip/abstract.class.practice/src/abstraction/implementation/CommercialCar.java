package abstraction.implementation;

public class CommercialCar extends Car {
	
	//Implementing abstract methods for CommercialCar Class

	public void start() {
		
		System.out.println("Commercial Car Started");
	}
	
	public void stop() {
		
		System.out.println("Commercial Car Stopped");
	}
	
}
