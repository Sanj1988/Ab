package abstraction.implementation;

public class SportsCar extends Car {

	//Implementing abstract methods for SportsCar Class
	
	public void start() {
		
		System.out.println("Sports Car Started");
	}
	
	public void stop() {
		
		System.out.println("Sports Car Stopped");
	}
	
}
