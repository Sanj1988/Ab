package abstraction.implementation;

abstract class Car {

	//Creating abstract methods which must be implement later if used in subclass
	
	abstract void start();
	
	abstract void stop();
	
}


